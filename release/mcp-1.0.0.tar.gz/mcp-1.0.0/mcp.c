#include <stdio.h>


int main(int argc, char **argv) {
    printf("Master C Programming");
    
    return 0;
}
